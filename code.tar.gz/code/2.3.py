import cv2 as cv
#import numpy as np
#import sys

# Play Video

cap = cv.VideoCapture('./videos/vtest.mp4')
while cap.isOpened():
    ret, frame = cap.read()
    #gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    cv.imshow('frame', frame)
    #cv.imshow('frame', gray)
    if cv.waitKey(1) == ord('q'):
        break

cap.release()
cv.destroyAllWindows()