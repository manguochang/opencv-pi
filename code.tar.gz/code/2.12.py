import cv2 as cv
import numpy as np
import sys

img1 = cv.imread("./images/butterfly.jpg")
cv.imshow("Original", img1)

img2 = cv.imread("./images/opencv-logo.png")
cv.imshow("Logo", img2)

logo = cv.resize(img2,None,fx=0.3, fy=0.3, interpolation = cv.INTER_CUBIC)
cv.imshow("Scaled", logo)

rows,cols,__=logo.shape
print(logo.shape)

alpha = 0.3

start_y = 100
start_x = 100

end_y = start_y+rows
end_x = start_x+cols

blended_portion = cv.addWeighted(logo,
    alpha,
    img1[start_y:end_y, start_x:end_x,:],
    1 - alpha,
    0,
    img1)
img1[start_y:end_y, start_x:end_x,:] = blended_portion

cv.imshow('blended portion',blended_portion)

cv.imshow('composited image', img1)

cv.waitKey(0)
cv.destroyAllWindows()
