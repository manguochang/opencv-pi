# Scaling

import numpy as np
import cv2 as cv

img = cv.imread('./images/butterfly.jpg')
cv.imshow("Original", img)

scale = 2.0

res1 = cv.resize(img,None,fx=scale, fy=scale, interpolation = cv.INTER_LINEAR)
res2 = cv.resize(img,None,fx=scale, fy=scale, interpolation = cv.INTER_CUBIC)
res3 = cv.resize(img,None,fx=scale, fy=scale, interpolation = cv.INTER_NEAREST)
res4 = cv.resize(img,None,fx=scale, fy=scale, interpolation = cv.INTER_AREA)

cv.imshow("LINEAR", res1)
cv.imshow("CUBIC", res2)
cv.imshow("NEAREST", res3)
cv.imshow("AREA", res4)

cv.waitKey(0)

cv.destroyAllWindows()