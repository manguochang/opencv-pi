import cv2
 
img = cv2.imread('./images/starry_night.jpg', cv2.IMREAD_UNCHANGED)
 
print('Original Dimensions : ',img.shape)
 
scale_percent = 30 # percent of original size
scale = scale_percent/100

width = int(img.shape[1]*scale)
height = int(img.shape[0]*scale)
dim = (width, height)
  
# resize image
resized = cv2.resize(img, dim, interpolation = cv2.INTER_AREA)
 
print('Resized Dimensions : ',resized.shape)

#cv2.rectangle(resized,(450,500),(600,680),(0,255,0),3)
cv2.rectangle(resized,(int(900*scale),int(1000*scale)),(int(1200*scale),int(1360*scale)),(0,255,0),3)

cv2.imshow("Resized image", resized)
px = resized[100,100]
print( px )
cv2.waitKey(0)
cv2.destroyAllWindows()