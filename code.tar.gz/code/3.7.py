import numpy as np
import cv2
from matplotlib import pyplot as plt

template = cv2.imread('./images/template.jpg',0)
frame = cv2.imread("./images/players.jpg",0)

cv2.imshow("Frame",frame)
cv2.imshow("Template",template)

result = cv2.matchTemplate(frame, template, cv2.TM_CCOEFF_NORMED)
cv2.imshow("Result", result)

min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
print('Min Value: {}, Min Location: {}'.format(min_val,min_loc))
print('Max Value: {}, Max Location: {}'.format(max_val,max_loc))
cv2.circle(result,max_loc, 15,255,2)
cv2.imshow("Matching",result)

cv2.imwrite("./images/screenshot.jpg",result)
img = cv2.imread('./images/screenshot.jpg')
cv2.imshow("", img)


cv2.waitKey(0)
cv2.destroyAllWindows()

