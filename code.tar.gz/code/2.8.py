import cv2 as cv
import numpy as np
import sys

# Convert BRG to Gray Scale image

img = cv.imread("./images/butterfly.jpg")
cv.imshow("Original",img)
hsv = cv.cvtColor(img, cv.COLOR_BGR2HSV)
cv.imshow("HSV",hsv)
cv.waitKey(0)
cv.destroyAllWindows()
