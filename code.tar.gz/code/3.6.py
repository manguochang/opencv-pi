import numpy as np
import cv2
from matplotlib import pyplot as plt

org = cv2.imread("./images/lena.png")
cv2.imshow("Org",org)

#img = cv2.imread("./images/tomatoes.jpg",1)

#hsv = cv2.cvtColor(org, cv2.COLOR_BGR2HSV)
#cv2.imshow("HSV",hsv) 

#res,thresh = cv2.threshold(hsv[:,:,0], 25, 255, cv2.THRESH_BINARY_INV)
#cv2.imshow("Canny",edges)

edges = cv2.Canny(org, 170, 70)
cv2.imshow("Canny",edges)

cv2.waitKey(0)
cv2.destroyAllWindows()
