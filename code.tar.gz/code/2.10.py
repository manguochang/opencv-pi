import cv2 as cv
import numpy as np
import sys

# Activity: Splitting and Merging Channels

img = cv.imread("./images/butterfly.jpg")
cv.imshow("Original", img)

b,g,r = cv.split(img)
cv.imshow("Blue", b)
cv.imshow("Green ", g)
cv.imshow("Red", r)

img2 = cv.merge((b,g,r))
cv.imshow("Merged", img2)

img[:,:,2]=0
cv.imshow("Modified", img)

cv.waitKey(0)
cv.destroyAllWindows()