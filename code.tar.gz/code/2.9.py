import cv2
import numpy as np
import sys

# Splitting BGR Channels

img = cv2.imread("./images/butterfly.jpg")
cv2.imshow("Original", img)

b,g,r = cv2.split(img)
cv2.imshow("Blue", b)
cv2.imshow("Green ", g)
cv2.imshow("Red", r)

cv2.waitKey(0)
cv2.destroyAllWindows()

# Splitting HSV Channels

img = cv2.imread("./images/butterfly.jpg")
cv2.imshow("Original", img)

hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
cv2.imshow("HSV",hsv)

h,s,v = cv2.split(hsv)
cv2.imshow("Hue", h)
cv2.imshow("Saturation ", s)
cv2.imshow("Value", v)

cv2.waitKey(0)
cv2.destroyAllWindows()
