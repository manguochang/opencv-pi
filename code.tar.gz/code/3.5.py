import numpy as np
import cv2
from matplotlib import pyplot as plt

# Adaptive Thresholding
img = cv2.imread('./images/sudoku.png',0)
cv2.imshow("Original",img)

ret, thresh_basic = cv2.threshold(img,45,255,cv2.THRESH_BINARY)
#plt.imshow(thresh_basic,cmap='gray')
#plt.show()
cv2.imshow("Basic Binary",thresh_basic)

thres_adapt = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 77, 1)
#plt.imshow(thres_adapt ,cmap='gray')
#plt.show()
cv2.imshow("Adaptive Threshold",thres_adapt)

cv2.waitKey(0)
cv2.destroyAllWindows()