# SIFT (Scale-Invariant Feature Transform)

import numpy as np
import cv2 as cv

img = cv.imread('./images/chess.jpg')
cv.imshow('org', img)
cv.waitKey(0)

gray= cv.cvtColor(img,cv.COLOR_BGR2GRAY)
cv.imshow('gray', gray)
cv.waitKey(0)

sift = cv.SIFT_create()

kp = sift.detect(gray,None)
img = cv.drawKeypoints(gray,kp,img)

cv.imshow('final', img)
cv.waitKey(0)

cv.imwrite('sift_keypoints.jpg',img)
cv.waitKey(0)
cv.destroyAllWindows()