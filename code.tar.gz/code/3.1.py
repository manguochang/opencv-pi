# Harris Corner Detector

import numpy as np
import cv2 as cv

filename = './images/chess.jpg'
img = cv.imread(filename)
gray = cv.cvtColor(img,cv.COLOR_BGR2GRAY)
cv.imshow('gray', gray)
cv.waitKey(0)

gray = np.float32(gray)
dst = cv.cornerHarris(gray,2,3,0.04)
cv.imshow('dst1', dst)
cv.waitKey(0)

## result is dilated for marking the corners, not important
dst = cv.dilate(dst,None)
cv.imshow('dst2', dst)
cv.waitKey(0)

## Threshold for an optimal value, it may vary depending on the image.
img[dst>0.01*dst.max()]=[0,0,255]
cv.imshow('dst',img)
if cv.waitKey(0) & 0xff == 27:
    cv.destroyAllWindows()