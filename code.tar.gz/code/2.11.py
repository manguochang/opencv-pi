import cv2 as cv
import numpy as np
import sys

# Image Addition

img = cv.imread("./images/butterfly.jpg")
print(img.shape)

cv.imshow("Original", img)

b,g,r = cv.split(img)
cv.imshow("Blue", b)
cv.imshow("Green ", g)
cv.imshow("Red", r)

img2 = cv.add(b,g,r)
print(img2.shape)
cv.imshow("Add", img2)

cv.waitKey(0)
cv.destroyAllWindows()