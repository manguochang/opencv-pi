import cv2 as cv
import numpy as np
import sys

# Test Image

img = cv.imread("./images/butterfly.jpg")
#img = cv.imread("./images/butterfly.jpg",0)  # Convert to Gray Scale

#cv2.namedWindow('image', cv2.WINDOW_NORMAL)
cv.imshow("Display window", img)

k = cv.waitKey(0)
if k == ord("s"):
    cv.imwrite("./images/starry_night.png", img)
cv.destroyAllWindows()